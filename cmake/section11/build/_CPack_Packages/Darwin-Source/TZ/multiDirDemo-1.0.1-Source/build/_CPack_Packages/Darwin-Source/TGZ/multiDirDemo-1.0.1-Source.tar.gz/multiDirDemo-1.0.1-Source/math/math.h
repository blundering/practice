#ifndef MATH_H
#define MATH_H
extern int add(int x, int y);
#endif